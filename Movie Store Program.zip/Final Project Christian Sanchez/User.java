// sort
// view

public class User {
    private String username = "user";
    private String password = "upassword";

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

}
