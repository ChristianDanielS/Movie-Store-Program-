// sort
// view

// add movies
// remove movies



public class Manager extends User {

    private String username = "manager";
    private String password = "mpassword";

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

}



