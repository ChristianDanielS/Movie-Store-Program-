import java.util.*;

public class MovieStore {

    ArrayList<Movie> films = null;
    String activeUser = "";
    Scanner s;

    public MovieStore() {
        s = new Scanner(System.in);
        films = new ArrayList<Movie>();
    }

    public String login() {
        User user = new User();
        Manager manager = new Manager();

        System.out.println("Enter username: ");
        String uname = s.next();

        System.out.println("Enter password: ");
        String pword = s.next();

        if (user.getUsername().equals(uname) && user.getPassword().equals(pword)) {
            System.out.println("Welcome User..");
            return "User";
        } else if (manager.getUsername().equals(uname) && manager.getPassword().equals(pword)) {
            System.out.println("Welcome Manager..");
            return "Manager";
        } else {
            System.out.println("Incorrect username and password, you are now a User.");
            return "User";
        }
    }

//    private void fillMoviesArrayList(ArrayList<Movie> films) {
//        films.add(new Movie("The Intouchables", 2011, "Actor 1", "SomeGenre1"));
//        films.add(new Movie("From Russia With Love", 1963, "Actor 2", "SomeGenre2"));
//        films.add(new Movie("The Long Voyage Home", 1940, "Actor 3", "SomeGenre3"));
//        films.add(new Movie("Easy Rider", 1969, "Actor 4", "SomeGenre4"));
//        films.add(new Movie("Dark Shadows", 2012, "Actor 5", "SomeGenre5"));
//        films.add(new Movie("Walk the Line", 2005, "Actor 1", "SomeGenre10"));
//        films.add(new Movie("The Help", 2011, "Actor 2", "SomeGenre9"));
//        films.add(new Movie("Meet the Parents", 2000, "Actor 3", "SomeGenre8"));
//        films.add(new Movie("The King's Speech", 2011, "Actor 4", "SomeGenre7"));
//        films.add(new Movie("Charlie and the Chocolate Factory", 2005, "Actor 5", "SomeGenre6"));
//        films.add(new Movie("Alice In Wonderland", 2009, "Actor 1", "SomeGenre11"));
//        films.add(new Movie("The Iron Lady", 2011, "Actor 2", "SomeGenre12"));
//        films.add(new Movie("Kaikohe Demolition", 2004, "Actor 3", "SomeGenre13"));
//        films.add(new Movie("Brokeback Mountain", 2005, "Actor 4", "SomeGenre14"));
//        films.add(new Movie("Gladiator", 2000, "Actor 5", "SomeGenre15"));
//        films.add(new Movie("The Parent Trap", 1961, "Actor 2", "SomeGenre16"));
//        films.add(new Movie("Happy-Go-Lucky", 2008, "Actor 1", "SomeGenre19"));
//        films.add(new Movie("The Big Wedding", 2013, "Actor 3", "SomeGenre17"));
//        films.add(new Movie("Searching for Sugar Man", 2012, "Actor 4", "SomeGenre18"));
//    }

    private void fillMoviesArrayList(ArrayList<Movie> films) {
        films.add(new Movie("The Intouchables", 2011, "Omar Sy", "Comedy"));
        films.add(new Movie("From Russia With Love", 1963, "Sean Connery", "Action"));
        films.add(new Movie("The Long Voyage Home", 1940, "John Wayne", "Drama"));
        films.add(new Movie("Easy Rider", 1969, "Peter Fonda", "Drama"));
        films.add(new Movie("Dark Shadows", 2012, "Johnny Depp", "Fantasy"));
        films.add(new Movie("Walk the Line", 2005, "Joaquin Phoenix", "Musical"));
        films.add(new Movie("The Help", 2011, "Octavia Spencer", "Drama"));
        films.add(new Movie("Meet the Parents", 2000, "Robert De Niro", "Comedy"));
        films.add(new Movie("The King's Speech", 2011, "Colin Firth", "Drama"));
        films.add(new Movie("Charlie and the Chocolate Factory", 2005, "Johnny Depp", "Fantasy"));
        films.add(new Movie("Alice In Wonderland", 2009, "Johnny Depp", "Fantasy"));
        films.add(new Movie("The Iron Lady", 2011, "Meryl Streep", "Drama"));
        films.add(new Movie("Kaikohe Demolition", 2004, "Ben Haretuku", "Documentary"));
        films.add(new Movie("Brokeback Mountain", 2005, "Jake Gyllenhaal", "Romance"));
        films.add(new Movie("Gladiator", 2000, "Russel Crowe", "Action"));
        films.add(new Movie("The Parent Trap", 1961, "Lindsay Lohan", "Comedy"));
        films.add(new Movie("Happy-Go-Lucky", 2008, "Sally Hawkins", "Comedy"));
        films.add(new Movie("The Big Wedding", 2013, "Robert De Niro", "Romance"));
        films.add(new Movie("Searching for Sugar Man", 2012, "Stephen Segerman", "Documentary"));
    }

    public void sortByTitle() {
        System.out.println("Sorting Based on Movie Title:");
        Collections.sort(films, Movie.titleComparator);

//        for (Movie movie : films) {
//            System.out.println(movie);
//        }
    }

    public void sortByYear() {
        System.out.println("Sorting Based on Movie Year:");
        Collections.sort(films, Movie.yearComparator);

//        for (Movie movie : films) {
//            System.out.println(movie);
//        }
    }

    public void sortByActor() {
        System.out.println("Sorting Based on Movie Actor:");
        Collections.sort(films, Movie.actorComparator);

//        for (Movie movie : films) {
//            System.out.println(movie);
//        }
    }

    public void sortByGenre() {
        System.out.println("Sorting Based on Movie Genre:");
        Collections.sort(films, Movie.genreComparator);

//        for (Movie movie : films) {
//            System.out.println(movie);
//        }
    }

    public void sortMenu() {
        System.out.println("Welcome to the SORT Menu");
        System.out.println("How would you like to sort the Movie List?");
        System.out.println("1] Sort by Title");
        System.out.println("2] Sort by Year");
        System.out.println("3] Sort by Actor");
        System.out.println("4] Sort by Genre");
        System.out.println("5] Go to MAIN Menu");
        System.out.println("6] Exit");
        int choice = s.nextInt();

        switch (choice) {
            case 1:
                sortByTitle();
                printMoviesArrayList(films);
                break;
            case 2:
                sortByYear();
                printMoviesArrayList(films);
                break;
            case 3:
                sortByActor();
                printMoviesArrayList(films);
                break;
            case 4:
                sortByGenre();
                printMoviesArrayList(films);
                break;
            case 5:
                start();
                break;
            case 6:
                goodBye();
                break;
            default:
                System.out.println("Incorrect option: ");
                sortMenu();
        }

    }
    public void goodBye()
    {
        System.out.println("Thank you for using my program!");
        System.out.println("Good bye!");
        System.exit(0);
    }
    public void searchAMovieTitle() {
        System.out.println("Enter the Movie Title you want to search: ");
        String title = s.nextLine();

        boolean result = false;

        for (int i = 0; i < films.size(); i++) {
            if (films.get(i).getTitle().contains(title)) {
                System.out.println("Movie Found: ");
                System.out.println(films.get(i));
                result = true;
                break;
            }
        }

        if (!result) {
            System.out.println(title + " not found!");
        }

    }

    private void printMoviesArrayList(ArrayList<Movie> films) {
        System.out.println("Movie Collection");
        System.out.println("================");
        for (Movie film : films) {
            System.out.println(film);
        }

    }

    public void displayMenuForUser() {
        System.out.println("Welcome USER!");

        System.out.println("Choose an option: ");
        System.out.println("1] Search a Movie Title");
        System.out.println("2] Sort a Movie");
        System.out.println("3] Display All Movies");
        System.out.println("4] Go back to the Main Menu");
        System.out.println("5] Exit");
        System.out.println("Enter your choice: ");
        int choice = s.nextInt();
        s.nextLine();
        switch (choice) {
            case 1:
                searchAMovieTitle();
                break;
            case 2:
                sortMenu();
                break;
            case 3:
                printMoviesArrayList(films);
                break;
            case 4:
                start();
                break;
            case 5:
                goodBye();
                break;
            default:
                System.out.println("Invalid choice..");

        }
        displayMenuForUser();
    }

    public void addAMovie()
    {
        System.out.println("Add a Movie Menu: ");
        System.out.println("Please Enter the Movie Title: ");
        String title = s.nextLine();
        System.out.println("Enter the year it was released: ");
        int year = Integer.parseInt(s.nextLine());
        System.out.println("Enter the Actors in the Movie " + title + ": ");
        String actor = s.nextLine();
        System.out.println("What is the Genre? ");
        String genre = s.nextLine();

        films.add(new Movie(title, year, actor, genre));
        System.out.println("Movie successfully added..");
        return;
    }

    public void removeAMovie()
    {
        System.out.println("Remove a Movie Menu: ");
        System.out.println("Please Enter the Movie Title you want to be removed: ");
        String title = s.nextLine();

        boolean result = false;

        for (int i = 0; i < films.size(); i++) {
            if (films.get(i).getTitle().contains(title)) {
                System.out.println("Movie Removed: ");
                System.out.println(films.remove(i));
                result = true;
                break;
            }
        }

        if (!result) {
            System.out.println(title + " not found!");
        }
        return;
    }

    public void displayMenuForManager() {
        System.out.println("Welcome MANAGER!");

        System.out.println("Choose an option: ");
        System.out.println("1] Search a Movie Title");
        System.out.println("2] Sort a Movie");
        System.out.println("3] Display All Movies");
        System.out.println("4] Add A Movie");       // add a movie
        System.out.println("5] Remove A Movie");    // remove a movie
        System.out.println("6] Go back to the Main Menu");
        System.out.println("7] Exit");
        System.out.println("Enter your choice: ");
        int choice = s.nextInt();
        s.nextLine();
        switch (choice) {
            case 1:
                searchAMovieTitle();
                break;
            case 2:
                sortMenu();
                break;
            case 3:
                printMoviesArrayList(films);
                break;
            case 4:
                addAMovie();
                break;
            case 5: // remove a movie
                removeAMovie();
                break;
            case 6:
                start();
                break;
            case 7:
                goodBye();
                break;
            default:
                System.out.println("Invalid choice..");

        }
        displayMenuForManager();

    }

    public void start() {
        System.out.println("--== Welcome to the MAIN MENU ==--");
        //activeUser = "user";    // used for testing the user account
        //activeUser = "manager";    // used for testing the user account
        activeUser = login();
        fillMoviesArrayList(films);

        if (activeUser.equalsIgnoreCase("USER")) {
            displayMenuForUser();
        } else if (activeUser.equalsIgnoreCase("MANAGER")) {
            displayMenuForManager();
        }

    }

    public static void main(String[] args) {
        new MovieStore().start();
    }

}
